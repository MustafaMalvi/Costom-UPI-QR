# UPI QR — build an APK using only your phone

This ZIP contains your original Android Studio project plus a GitHub Actions workflow. A laptop is not required, but you need a GitHub account and an internet connection. The APK will be built remotely.

## Phone-only setup

1. Download this ZIP, then also keep your original `UpiQr-AndroidStudio-Project.zip` available on your phone.
2. In GitHub, create a new empty repository. Do not add a README, license, or .gitignore.
3. Upload **only the original file** `UpiQr-AndroidStudio-Project.zip` to the repository and commit it.
4. In that repository, choose **Add file → Create new file**.
5. Enter the filename `.github/workflows/android.yml`.
6. Open `BUILD-APK-FROM-PHONE.md` from this prepared ZIP or the `android.yml` file inside `.github/workflows/` and copy the complete workflow text into GitHub's editor. Commit the file to the `main` branch.
7. Open the repository's **Actions** tab and choose **Build Android APK**. If it hasn't started automatically, choose **Run workflow**.
8. Wait for the workflow to complete successfully. Open the run and find **Artifacts** near the bottom.
9. Download `UpiQr-debug-apk`. Extract that downloaded ZIP on your phone to find `app-debug.apk`.
10. Tap `app-debug.apk` to install it. If prompted, allow your browser or file manager to install unknown apps.

## Workflow file to copy

The workflow file is included at `.github/workflows/android.yml` in this prepared ZIP. You need to create that file in your GitHub repository; GitHub does not execute a workflow simply because it is inside an uploaded ZIP.

This is a debug APK for testing, not a Play Store release. The remote build can still reveal source-code or dependency errors; if so, the Actions log will show the failure.
