package com.upiqr.app

import android.content.Context
import android.app.Activity
import android.graphics.Bitmap
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.UUID
import kotlin.math.absoluteValue

// ---------- Data ----------

data class UpiAccount(val id: String, val name: String, val upiId: String)

class AccountStore(context: Context) {
    private val prefs = context.getSharedPreferences("upi_qr_store", Context.MODE_PRIVATE)

    fun load(): List<UpiAccount> {
        val raw = prefs.getString("accounts", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                UpiAccount(o.getString("id"), o.getString("name"), o.getString("upiId"))
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun save(list: List<UpiAccount>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("name", it.name).put("upiId", it.upiId))
        }
        prefs.edit().putString("accounts", arr.toString()).apply()
    }
}

// ---------- QR helpers ----------

fun upiUri(a: UpiAccount, amount: String): String {
    val sb = StringBuilder("upi://pay?pa=")
        .append(Uri.encode(a.upiId, "@"))
        .append("&pn=").append(Uri.encode(a.name))
        .append("&cu=INR")
    val v = amount.toDoubleOrNull()
    if (v != null && v > 0) {
        sb.append("&am=").append(String.format(Locale.US, "%.2f", v))
    }
    return sb.toString()
}

fun makeQr(content: String, size: Int = 720): Bitmap {
    val hints = mapOf(
        EncodeHintType.MARGIN to 1,
        EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.M
    )
    val matrix = QRCodeWriter().encode(content, BarcodeFormat.QR_CODE, size, size, hints)
    val pixels = IntArray(size * size)
    for (y in 0 until size) {
        val row = y * size
        for (x in 0 until size) {
            pixels[row + x] = if (matrix[x, y]) 0xFF000000.toInt() else 0xFFFFFFFF.toInt()
        }
    }
    return Bitmap.createBitmap(pixels, size, size, Bitmap.Config.ARGB_8888)
}

fun sanitizeAmount(s: String): String? =
    if (Regex("^\\d{0,7}(\\.\\d{0,2})?$").matches(s)) s else null

fun validAmount(s: String): Boolean = (s.toDoubleOrNull() ?: 0.0) > 0.0

// ---------- Activity ----------

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        updateQrWidgets(applicationContext)
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Color(0xFF1A5FD0),
                    background = Color(0xFFF4F6FB),
                    surface = Color.White
                )
            ) {
                App(applicationContext)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(context: Context) {
    val store = remember { AccountStore(context) }
    val accounts = remember { mutableStateListOf<UpiAccount>().apply { addAll(store.load()) } }
    var amount by rememberSaveable { mutableStateOf("") }
    var selectedId by rememberSaveable { mutableStateOf<String?>(null) }
    var showQrSection by rememberSaveable { mutableStateOf(false) }
    var showAdd by remember { mutableStateOf(false) }

    val selected = accounts.find { it.id == selectedId } ?: accounts.firstOrNull()

    BackHandler(enabled = showQrSection) { showQrSection = false }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text(if (showQrSection) "QR Section" else "UPI QR", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    if (showQrSection) {
                        IconButton(onClick = { showQrSection = false }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                        }
                    }
                },
                actions = {
                    if (!showQrSection) {
                        TextButton(
                            onClick = { showQrSection = true },
                            enabled = accounts.isNotEmpty()
                        ) { Text("QR Section") }
                    }
                }
            )
        }
    ) { padding ->
        if (showQrSection && accounts.isNotEmpty()) {
            QrSection(
                accounts = accounts,
                startIndex = accounts.indexOfFirst { it.id == selected?.id }.coerceAtLeast(0),
                onPageChange = { selectedId = it },
                amount = amount,
                onAmount = { amount = it },
                modifier = Modifier.padding(padding)
            )
        } else {
            HomeScreen(
                accounts = accounts,
                selected = selected,
                onSelect = { selectedId = it.id },
                amount = amount,
                onAmount = { amount = it },
                onAddClick = { showAdd = true },
                onDelete = { acc ->
                    accounts.remove(acc)
                    store.save(accounts.toList())
                    updateQrWidgets(context)
                    if (selectedId == acc.id) selectedId = accounts.firstOrNull()?.id
                },
                modifier = Modifier.padding(padding)
            )
        }
    }

    if (showAdd) {
        AddDialog(
            onDismiss = { showAdd = false },
            onSave = { name, upi ->
                val acc = UpiAccount(UUID.randomUUID().toString(), name, upi)
                accounts.add(acc)
                store.save(accounts.toList())
                updateQrWidgets(context)
                selectedId = acc.id
                showAdd = false
            }
        )
    }
}

// ---------- Home ----------

@Composable
fun HomeScreen(
    accounts: List<UpiAccount>,
    selected: UpiAccount?,
    onSelect: (UpiAccount) -> Unit,
    amount: String,
    onAmount: (String) -> Unit,
    onAddClick: () -> Unit,
    onDelete: (UpiAccount) -> Unit,
    modifier: Modifier = Modifier
) {
    var confirmDelete by remember { mutableStateOf<UpiAccount?>(null) }

    Column(
        modifier
            .fillMaxSize()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            onClick = onAddClick
        ) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(Modifier.weight(1f)) {
                    Text("+ Add", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Text("Add another UPI account", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                }
                Icon(Icons.Default.Add, contentDescription = "Add UPI ID", tint = MaterialTheme.colorScheme.primary)
            }
        }
        if (selected == null) {
            Spacer(Modifier.height(16.dp))
            Text(
                "No UPI ID added yet",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
            Text(
                "Add a UPI ID with a name to create its QR code.",
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
            Button(onClick = onAddClick, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(Modifier.size(8.dp))
                Text("Add UPI ID")
            }
        } else {
            val pagerState = rememberPagerState(
                initialPage = accounts.indexOfFirst { it.id == selected.id }.coerceAtLeast(0)
            ) { accounts.size.coerceAtLeast(1) }

            LaunchedEffect(pagerState.currentPage, accounts.size) {
                accounts.getOrNull(pagerState.currentPage)?.let { onSelect(it) }
            }

            HorizontalPager(
                state = pagerState,
                contentPadding = PaddingValues(horizontal = 8.dp),
                pageSpacing = 12.dp,
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) { page ->
                accounts.getOrNull(page)?.let { acc ->
                    QrCard(acc, amount, Modifier.fillMaxWidth())
                }
            }
            Text(
                "${pagerState.currentPage + 1} / ${accounts.size}  •  swipe left or right",
                style = MaterialTheme.typography.labelLarge,
                color = Color.Gray,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )

            AmountField(amount, onAmount)

            TextButton(
                onClick = { confirmDelete = selected },
                modifier = Modifier.align(Alignment.CenterHorizontally)
            ) {
                Icon(Icons.Default.Delete, contentDescription = null)
                Spacer(Modifier.size(6.dp))
                Text("Delete this UPI ID")
            }
        }
    }

    confirmDelete?.let { acc ->
        AlertDialog(
            onDismissRequest = { confirmDelete = null },
            title = { Text("Delete \"${acc.name}\"?") },
            text = { Text(acc.upiId) },
            confirmButton = {
                TextButton(onClick = { onDelete(acc); confirmDelete = null }) { Text("Delete") }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = null }) { Text("Cancel") }
            }
        )
    }
}

// ---------- QR section (swipe pager) ----------

@Composable
fun QrSection(
    accounts: List<UpiAccount>,
    startIndex: Int,
    onPageChange: (String) -> Unit,
    amount: String,
    onAmount: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val pagerState = rememberPagerState(
        initialPage = startIndex.coerceIn(0, (accounts.size - 1).coerceAtLeast(0))
    ) { accounts.size }

    LaunchedEffect(pagerState.currentPage) {
        accounts.getOrNull(pagerState.currentPage)?.let { onPageChange(it.id) }
    }

    Column(
        modifier
            .fillMaxSize()
            .imePadding(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        HorizontalPager(
            state = pagerState,
            contentPadding = PaddingValues(horizontal = 32.dp),
            pageSpacing = 16.dp,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) { page ->
            val acc = accounts.getOrNull(page)
            if (acc != null) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .graphicsLayer {
                            val offset = ((pagerState.currentPage - page) +
                                    pagerState.currentPageOffsetFraction).absoluteValue.coerceIn(0f, 1f)
                            val s = 1f - 0.12f * offset
                            scaleX = s
                            scaleY = s
                            alpha = 1f - 0.5f * offset
                        }
                ) {
                    QrCard(acc, amount, Modifier.fillMaxWidth())
                }
            }
        }

        Text(
            "${pagerState.currentPage + 1} / ${accounts.size}  •  swipe left or right",
            style = MaterialTheme.typography.labelLarge,
            color = Color.Gray
        )
        if (accounts.size in 2..8) {
            Row(
                Modifier.padding(top = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                repeat(accounts.size) { i ->
                    Box(
                        Modifier
                            .size(if (i == pagerState.currentPage) 10.dp else 7.dp)
                            .clip(CircleShape)
                            .background(
                                if (i == pagerState.currentPage) MaterialTheme.colorScheme.primary
                                else Color.LightGray
                            )
                    )
                }
            }
        }

        AmountField(
            amount, onAmount,
            Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
        )
    }
}

// ---------- Shared pieces ----------

@Composable
fun QrCard(account: UpiAccount, amount: String, modifier: Modifier = Modifier) {
    val bitmap = remember(account, amount) { makeQr(upiUri(account, amount)) }
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                account.name,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = Color.Black,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(12.dp))
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = "QR code for ${account.name}",
                filterQuality = FilterQuality.None,
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
            )
            Spacer(Modifier.height(12.dp))
            Text(account.upiId, color = Color.DarkGray, textAlign = TextAlign.Center)
            Spacer(Modifier.height(4.dp))
            Text(
                if (validAmount(amount)) "Pay ₹$amount" else "Any amount",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.primary
            )
        }
    }
}

@Composable
fun AmountField(amount: String, onAmount: (String) -> Unit, modifier: Modifier = Modifier) {
    val focus = LocalFocusManager.current
    val clearButton: @Composable (() -> Unit)? =
        if (amount.isNotEmpty()) {
            { TextButton(onClick = { onAmount("") }) { Text("Clear") } }
        } else null

    OutlinedTextField(
        value = amount,
        onValueChange = { v -> sanitizeAmount(v)?.let(onAmount) },
        label = { Text("Amount (₹) – optional") },
        prefix = { Text("₹ ") },
        singleLine = true,
        keyboardOptions = KeyboardOptions(
            keyboardType = KeyboardType.Decimal,
            imeAction = ImeAction.Done
        ),
        keyboardActions = KeyboardActions(onDone = { focus.clearFocus() }),
        trailingIcon = clearButton,
        modifier = modifier.fillMaxWidth()
    )
}

@Composable
fun AddDialog(onDismiss: () -> Unit, onSave: (String, String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var upi by remember { mutableStateOf("") }
    val valid = name.isNotBlank() && Regex("^[^\\s@]+@[^\\s@]+$").matches(upi.trim())

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add UPI ID") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Name (e.g. Shop QR, Rahul)") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = upi,
                    onValueChange = { upi = it.replace(" ", "") },
                    label = { Text("UPI ID (e.g. name@bank)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(name.trim(), upi.trim()) }, enabled = valid) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}


// ---------- Android home-screen QR widget ----------

fun updateQrWidgets(context: Context) {
    val manager = AppWidgetManager.getInstance(context)
    val ids = manager.getAppWidgetIds(ComponentName(context, UpiQrWidgetProvider::class.java))
    if (ids.isNotEmpty()) UpiQrWidgetProvider.update(context, manager, ids)
}

class UpiQrWidgetProvider : android.appwidget.AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, appWidgetIds: IntArray) {
        update(context, manager, appWidgetIds)
    }

    companion object {
        fun update(context: Context, manager: AppWidgetManager, ids: IntArray) {
            val prefs = context.getSharedPreferences("upi_qr_widget_choices", Context.MODE_PRIVATE)
            val accounts = AccountStore(context).load()
            ids.forEach { id ->
                val savedId = prefs.getString("account_$id", null)
                val account = accounts.firstOrNull { it.id == savedId } ?: accounts.firstOrNull()
                val views = android.widget.RemoteViews(context.packageName, R.layout.upi_qr_widget)
                if (account == null) {
                    views.setTextViewText(R.id.widget_title, "UPI QR")
                    views.setTextViewText(R.id.widget_subtitle, "Open app to add a UPI ID")
                    views.setImageViewBitmap(R.id.widget_qr, null)
                } else {
                    views.setTextViewText(R.id.widget_title, account.name)
                    views.setTextViewText(R.id.widget_subtitle, account.upiId)
                    try {
                        views.setImageViewBitmap(R.id.widget_qr, makeQr(upiUri(account, ""), 360))
                    } catch (_: Exception) { }
                }
                val intent = android.content.Intent(context, MainActivity::class.java)
                val pending = android.app.PendingIntent.getActivity(
                    context, id, intent,
                    android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.widget_root, pending)
                manager.updateAppWidget(id, views)
            }
        }
    }
}

/** Lets the user choose which saved UPI account belongs to each individual home-screen widget. */
class WidgetConfigureActivity : Activity() {
    private var widgetId: Int = AppWidgetManager.INVALID_APPWIDGET_ID

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setResult(RESULT_CANCELED)
        widgetId = intent?.getIntExtra(
            AppWidgetManager.EXTRA_APPWIDGET_ID,
            AppWidgetManager.INVALID_APPWIDGET_ID
        ) ?: AppWidgetManager.INVALID_APPWIDGET_ID

        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish()
            return
        }

        val accounts = AccountStore(this).load()
        if (accounts.isEmpty()) {
            android.app.AlertDialog.Builder(this)
                .setTitle("No UPI accounts")
                .setMessage("Open UPI QR and add a UPI ID first. You can add this widget again afterward.")
                .setPositiveButton("OK") { _, _ -> finish() }
                .setOnCancelListener { finish() }
                .show()
            return
        }

        val labels = accounts.map { "${it.name} — ${it.upiId}" }.toTypedArray()
        android.app.AlertDialog.Builder(this)
            .setTitle("Choose UPI account for widget")
            .setItems(labels) { _, which ->
                val selected = accounts[which]
                getSharedPreferences("upi_qr_widget_choices", Context.MODE_PRIVATE)
                    .edit().putString("account_$widgetId", selected.id).apply()

                val manager = AppWidgetManager.getInstance(this)
                UpiQrWidgetProvider.update(this, manager, intArrayOf(widgetId))

                val result = android.content.Intent().putExtra(
                    AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId
                )
                setResult(RESULT_OK, result)
                finish()
            }
            .setOnCancelListener { finish() }
            .show()
    }
}
